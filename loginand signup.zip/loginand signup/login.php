 <?php
session_start(); // Start the session

if(isset($_POST['submit'])) {
    // Check if $_POST keys are set
    if(isset($_POST['email'], $_POST['password'])) {
        // Assign values to variables
        $email = $_POST['email'];
        $password = $_POST['password'];
    }
    // Check if MySQLi extension is available
    if (!class_exists('mysqli')) {
        die('MySQLi extension is not enabled or installed.');
    }
    
    // Connect to the database
    $conn = new mysqli('localhost', 'root', '', 'carrent');
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    } else {
        // Check if the form is submitted
        if (!empty($_POST['submit'])) { // Change from 'save' to 'submit'
            // Insert email and password into the login table
            $insert_query = "INSERT INTO login (email, password) VALUES ('$email', '$password')";
            if ($conn->query($insert_query) === TRUE) {
                $_SESSION['email'] = $email;
                // Redirect to the main page upon successful login
                header("Location: main.html");
                exit(); // Ensure no further code execution after redirection
            } else {
                echo "Error: " . $insert_query . "<br>" . $conn->error;
            }
        }
    }
}

// Flush output buffer
ob_flush();
?>
