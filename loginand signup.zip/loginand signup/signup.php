 <?php
// Check if form is submitted and $_POST is set
if(isset($_POST['submit'])) {
    // Check if $_POST keys are set
    if(isset($_POST['name'], $_POST['email'], $_POST['phone'], $_POST['city'], $_POST['password'])) {
        // Assign values to variables
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $city = $_POST['city'];
        $password = $_POST['password'];

        // Check if MySQLi extension is available
        if (!class_exists('mysqli')) {
            die('MySQLi extension is not enabled or installed.');
        }
        
        // Connect to the database
        $conn = new mysqli('localhost', 'root', '', 'carrent');
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        } else {
            // Prepare and execute the SQL statement
            $stmt = $conn->prepare("INSERT INTO users (name, email, phone, city, password) VALUES (?, ?, ?, ?, ?)");
            $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password
            $stmt->bind_param("sssss", $name, $email, $phone, $city, $hashed_password); // Bind hashed password
            if ($stmt->execute()) {
                // Registration successful, redirect to the login page
                header("Location: login.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
            $conn->close();
        }
    } else {
        // Handle case where $_POST keys are not set
        die('Some form fields are missing.');
    }
} else {
    // Handle case where form is not submitted
    echo 'Form is not submitted.';
}
?>
